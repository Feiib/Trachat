package com.fei.aitravelassistant.constant;

public interface FileConstant {
    String FILE_SAVE_PATH = System.getProperty("user.dir") + "/tmp" ;
}

